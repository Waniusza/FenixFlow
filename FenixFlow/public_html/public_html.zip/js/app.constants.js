App
    .constant("APP_CONFIG", {
        "FILE_PREFIX": "/FenixFlow"
    });